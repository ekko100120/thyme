CREATE FUNCTION "_pg_keysequal"(smallint[], smallint[])
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
select $1 operator(pg_catalog.<@) $2 and $2 operator(pg_catalog.<@) $1
$$;

